"""
ForexSAI — Demo Deney Botu / Configuration
==========================================
Bu dosya hesap bilgilerini içerir — repoya commit ETME (gitignore'da).

Bot ne yapar:
  - ForexSAI backend'inden PULSE sinyali (pulse1/2/3) çeker; backend'in
    momentum-continuation filtresinden geçen 4 DOĞRULANMIŞ scope için işlem açar:
      NDX:BUY, USOIL:SELL, GDAXI:BUY, USOIL:BUY  (hepsi OOS+friction-doğrulandı).
  - Giriş HİBRİT: normal momentumda 1m S/R pullback (pending limit), aşırı
    momentumda market continuation. TP S/R'den ya da sabit; SL araştırılmış sabit.
  - DOKUNMAZ: XAUUSD (edge yok), NDX:SELL (marjinal), GDAXI:SELL (OOS'ta çöktü).
  - Risk: scope başına 1 poz + global MAX_TOTAL_POSITIONS + günlük DAILY_MAX_LOSS halt.
  - SL forensiği: her giriş 'parmak izi' loglanır (sl_forensics.py ile analiz edilir).
  - LIVE_TRADING=False sadece loglar AMA pending emir yerleştirmez → gerçek fill
    görmek (S/R hibrit'i ölçmek) için demo'da True yap.
"""

# ─── MT5 Demo Hesabı (IC Markets) ────────────────────────────────────────────
MT5_ACCOUNT = 52890969
MT5_PASSWORD = "!njnF5ZkSoZdTs"
MT5_SERVER = "ICMarketsSC-Demo"

# 2 MT5 aynı anda çalışıyorsa bu botun BAĞLANACAĞI terminalin yolunu ver.
# Demo MT5'i ayrı klasöre kurduysan ör:  r"C:\MT5_Demo\terminal64.exe"
# Boş bırakırsan varsayılan/açık terminale bağlanır (tek terminal varsa yeter).
MT5_TERMINAL_PATH = r""

# ─── ForexSAI Backend ────────────────────────────────────────────────────────
FOREXSAI_API = "https://upbeat-flow-production.up.railway.app"

# ─── Walk-forward ile doğrulanmış robust scope'lar + türetilmiş TP/SL ────────
# Kaynak: rolling walk-forward analizi (2026-05-21). En iyi model ailesi = PULSE.
#   NDX BUY  : pulse2 4/4 fold, OOS +23.8/trade
#   GDAXI SELL: pulse3 3/4 fold, OOS +6.3/trade
#   USOIL SELL: pulse3 4/4 fold, OOS +0.77%/trade
# 2026-06-14 eklenenler (momentum filtresi + sertlik bataryası ile doğrulandı):
#   GDAXI BUY : 3/3 split +EV; bootstrap P(WR>be)=%99.9; placebo p=0.000
#   USOIL BUY : 3/3 split +EV; bootstrap P(WR>be)=%100; filtresiz −EV'yi çeviriyor
#   Bu iki yön SADECE momentum filtresi (backend kapısı) ile +EV — filtresiz
#   açılmamalı, bu yüzden MOMENTUM_FILTERED_SCOPES'a da eklendiler.
# tp/sl: index'lerde puan, USOIL'de yüzde (is_pct=True). Ters yönler kendi
# sembollerinin sabit tp/sl'ini aynalıyor (simetrik puan/yüzde mesafesi).
ROBUST_SCOPES = {
    "NDX.INDX:BUY":    {"tp": 80,   "sl": 110,  "is_pct": False,
                         "models": ["pulse1", "pulse2", "pulse3"]},
    "USOIL.FOREX:SELL":{"tp": 1.04, "sl": 1.49, "is_pct": True,
                         "models": ["pulse1", "pulse2", "pulse3"]},
    "GDAXI.INDX:BUY":  {"tp": 67,   "sl": 119,  "is_pct": False,
                         "models": ["pulse1", "pulse2", "pulse3"]},
    "USOIL.FOREX:BUY": {"tp": 1.04, "sl": 1.49, "is_pct": True,
                         "models": ["pulse1", "pulse2", "pulse3"]},
}
# NOT: GDAXI.INDX:SELL ÇIKARILDI (2026-06-24) — OOS'ta çöktü (TEST %58.3 < be %64),
# momentum filtresi yoktu → filtresiz naked −EV açıyordu. 4 scope da momentum-filtreli.

# ─── XAUUSD — S/R-girişi denemesi için HAZIR (varsayılan KAPALI) ─────────────
# Intraday XAU geçmişte naive market girişiyle edge YOK (1.5 hafta canlı: −16.8k,
# WR ~%51, saf whipsaw). Senin S/R-girişi mimarinle TEKRAR denenebilir AMA önce
# LIVE_TRADING=False gözlemde S/R-WR'ı başabaşı (~%58) geçmeli. tp/sl: eski
# araştırılmış değerini buraya yaz (3/5'ten genişti — tam sayıyı teyit et).
# Açmak için yorumu kaldır:
# ROBUST_SCOPES["XAUUSD:BUY"]  = {"tp": 8.0, "sl": 6.0, "is_pct": False,
#                                 "models": ["pulse1", "pulse2", "pulse3"]}
# ROBUST_SCOPES["XAUUSD:SELL"] = {"tp": 8.0, "sl": 6.0, "is_pct": False,
#                                 "models": ["pulse1", "pulse2", "pulse3"]}

# ForexSAI sembolü → broker (IC Markets / Raw Trading) MT5 sembolü.
# Bu broker'da doğrulananlar: USTEC (NASDAQ), XTIUSD (WTI petrol).
# DAX büyük ihtimalle "DE40" — bot başlangıçta endeks sembollerini
# yazdırır; doğrusunu görüp buradan düzelt.
SYMBOL_MAP = {
    "NDX.INDX":    "USTEC",
    "GDAXI.INDX":  "DE40",
    "USOIL.FOREX": "XTIUSD",
}

# ─── Momentum-continuation filtresi (OOS-doğrulandı 2026-06-12, +2 yön 06-14) ─
# Bu scope'lar backend'in /api/bot/trade-signal kapısında momentum filtresinden
# geçer (yalnızca trend-devamı girişleri botun sabit uzak TP'sine ulaşıyor).
# Held-out TEST + blind eşik + haftalık walk-forward ile doğrulandı:
#   NDX.INDX:BUY     filtresiz TEST %51.4 (−EV) → filtreli %78.6
#   USOIL.FOREX:SELL filtresiz TEST %71.4       → filtreli %96.6
#   GDAXI.INDX:BUY   3/3 split +EV; bootstrap %99.9; placebo p=0.000   (06-14)
#   USOIL.FOREX:BUY  3/3 split +EV; bootstrap %100; filtresiz −EV→+EV  (06-14)
# GDAXI.INDX:SELL bilerek YOK — OOS'ta çöktü (TEST %58.3 < be %64). XAUUSD ve
# NDX SELL de YOK (XAU SELL 2x friction'da −EV; NDX SELL marjinal).
# Backend ulaşılamazsa bu scope'lar fallback'te AÇILMAZ (filtre doğrulanamaz).
MOMENTUM_FILTERED_SCOPES = {
    "NDX.INDX:BUY", "USOIL.FOREX:SELL", "GDAXI.INDX:BUY", "USOIL.FOREX:BUY",
}

# ─── İşlem ayarları ──────────────────────────────────────────────────────────
LOT_SIZE = 0.10               # demo — lot büyüklüğü
POLL_SECONDS = 60             # sinyal kontrol aralığı
MIN_MODEL_VOTES = 1           # kaç pulse modeli aynı yönü vermeli (1-3)
ONLY_CONFIRM_SIGNALS = True   # True: sadece CONFIRM sinyalleri (SCOUT atlanır)
MAX_OPEN_PER_SCOPE = 1        # scope başına aynı anda en fazla kaç pozisyon
MAX_TOTAL_POSITIONS = 6       # GLOBAL tavan: aynı anda en fazla kaç açık pozisyon (tüm scope)
DAILY_MAX_LOSS = 3000.0       # bugünkü realize zarar bunu aşarsa yeni giriş DUR (0=kapalı).
                              # "bir kötü gün testi domine etmesin" — demo'da ~%3
DEVIATION_POINTS = 30         # emir slippage toleransı
MAGIC_NUMBER = 52890969       # bu botun emirlerini ayırt etmek için

# ─── S/R-temelli giriş mimarisi (1m destek/direnç) ──────────────────────────
# Sinyal gelince market'ten KOVALAMAK yerine: 1m grafikte yüksek-dokunuşlu S/R
# bölgeleri bul → BUY'ı en yakın DESTEK'ten, SELL'i en yakın DİRENÇ'ten pending
# LIMIT ile gir. TP = giriş yönündeki bir sonraki S/R bölgesi (yoksa sabit tp).
# Uygun S/R yoksa veya çok uzaksa işlem AÇILMAZ (yukarıdan/aşağıdan kovalama yok).
USE_SR_ENTRY = True               # False → eski market girişi (open_trade_v2)
ZONE_LOOKBACK = 100               # son kaç 1m mum analiz edilsin
ZONE_MIN_TOUCH_CANDLES = 4        # bir bölge S/R sayılsın diye min AYRI mum (>3)
# 'cap' bölge genişliği — fiyat birimi (NDX 10 puan, XAU 3 $ … senin spec'in):
ZONE_WIDTH = {
    "NDX.INDX":    10.0,
    "GDAXI.INDX":  10.0,
    "USOIL.FOREX": 0.12,
    "XAUUSD":      3.0,
}
# S/R bu kadar uzaktaysa kovalama yok → işlem açma (pending limit dolmaz):
SR_MAX_ENTRY_DIST = {
    "NDX.INDX": 45.0, "GDAXI.INDX": 45.0, "USOIL.FOREX": 0.60, "XAUUSD": 12.0,
}
# S/R-temelli TP en az bu kadar uzak olmalı (çok yakın/degenerate TP'yi engelle;
# bu mesafeden yakınsa sabit tp'ye düşer):
SR_MIN_TP_DIST = {
    "NDX.INDX": 15.0, "GDAXI.INDX": 15.0, "USOIL.FOREX": 0.15, "XAUUSD": 1.5,
}
PENDING_EXPIRY_MIN = 30           # limit emir bu sürede dolmazsa iptal (kovalama yok)
SR_FALLBACK_MARKET = False        # True: uygun S/R yoksa eski market girişine düş

# ─── HİBRİT giriş: normal momentum → S/R pullback; AŞIRI momentum → market ────
# Varsayılan = senin S/R-pullback sistemin. AMA momentumda görünür fazlalık varsa
# (fiyat M15 EMA20'den çok uzaklaşmış), geri çekilmeyi bekleme — momentum-
# continuation gibi HEMEN market'ten gir (doğrulanmış edge market girişiyle test
# edildi). Ölçü = işaretli dist(EMA20)/ATR (M15), backend filtresinin göstergesi.
HYBRID_ENTRY = True
MOMENTUM_MTF_BARS = 50            # momentum için kaç M15 mum çekilsin
MOMENTUM_EXCESS_ATR = 2.0        # M15 dist(EMA20)/ATR bunu AŞARSA → market continuation
                                 # (altındaysa → S/R pullback). Filtre eşiği 0.8 idi;
                                 # 2.0 = belirgin aşırılık. Yükselt → daha sık S/R.
# Seansa göre eşik çarpanı: belirli saatlerde momentum doğal yüksek → eşiği düşür
# (market'e daha kolay geç); sakin saatlerde yükselt (S/R pullback'e meylet).
SESSION_MOM_FACTOR = {"high": 0.7, "normal": 1.0, "quiet": 1.4, "eia": 0.55}
# Seanslar borsa YEREL saatine göre (DST otomatik — yaz/kış kayması zoneinfo ile
# kendiliğinden çözülür; Windows'ta `tzdata` paketi gerekir, requirements'ta var).
SESSION_TZ = {
    "NDX.INDX":    "America/New_York",
    "GDAXI.INDX":  "Europe/Berlin",
    "USOIL.FOREX": "America/New_York",
    "XAUUSD":      "America/New_York",
}
# Yüksek-momentum pencereleri — (başlangıç, bitiş) YEREL ondalık saat (9.5 = 09:30):
HIGH_MOM_WINDOWS = {
    "GDAXI.INDX":  [(9.0, 10.0)],             # Frankfurt açılışı SADECE İLK SAAT 09:00–10:00 yerel
    "USOIL.FOREX": [(9.0, 12.0)],             # US oil sabahı (EIA Çar penceresi ayrıca aşağıda)
    "NDX.INDX":    [(9.5, 11.0)],             # NY açılışı 09:30 ET
    "XAUUSD":      [(3.0, 5.0), (8.0, 11.0)], # Londra açılışı + NY
}
QUIET_LOCAL = (21.0, 6.0)   # yerel 21:00–06:00 (gece) = sakin → eşik yüksek
# EIA Haftalık Petrol Raporu: ÇARŞAMBA 10:30 ET — petrolde en keskin momentum spike.
# O pencerede en agresif momentum-continuation (eşik en düşük). (Pzt tatilse Per'e
# kayar; nadir, istenirse eklenir.)
EIA_SYMBOL = "USOIL.FOREX"
EIA_WEEKDAY = 2             # 0=Pzt … 2=Çar
EIA_WINDOW_ET = (9.75, 12.5)   # genişletildi: 09:45 (rapor öncesi pozisyon) → 12:30 ET (reaksiyon kuyruğu)

# ─── data_recorder.py — sürekli OHLC + indicator kaydı (MT5 → Supabase) ──────
# Bridge'e bağımlı DEĞİL: MT5'ten doğrudan çeker → candle_cache (OHLC) +
# indicator_snapshots (tüm göstergeler) upsert eder → 1m donması biter.
# Botla AYRI süreç olarak çalıştır: python data_recorder.py
RECORDER_SYMBOLS = {          # ForexSAI adı → MT5 broker sembolü
    "NDX.INDX":    "USTEC",
    "GDAXI.INDX":  "DE40",
    "USOIL.FOREX": "XTIUSD",
    "XAUUSD":      "XAUUSD",
}
RECORDER_TIMEFRAMES = ["1m", "5m", "15m", "30m", "1h"]
RECORDER_POLL = 60            # saniye (1m için ideal)
# İlk koşuda her TF için kaç bar çekilsin (geçmiş boşluğu doldur ~2 hafta);
# sonraki poll'lerde küçük artımlı pencere kullanılır.
RECORDER_BACKFILL_BARS = {"1m": 20000, "5m": 6000, "15m": 3000, "30m": 2000, "1h": 1500}
RECORDER_MAX_IND_PER_POLL = 120   # poll başına indicator hesabı tavanı (1m gap'i OHLC olarak dolar)
# Supabase — backend/.env'den kopyala (service-role key YAZMA yetkisi için şart):
SUPABASE_URL = "https://xdmtbykebfpqutfgdfqs.supabase.co"
SUPABASE_SERVICE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhkbXRieWtlYmZwcXV0ZmdkZnFzIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2ODI0NDIwNSwiZXhwIjoyMDgzODIwMjA1fQ.oOr7u4poVBy3tdNaA0sHETTODHlxc7SfZTYAW-nxrQk"

# ─── CHANNEL_REVERSION scope (MEAN-REVERSION — momentum'dan AYRI) ─────────────
# Araştırma (sr_rejection_research, 2026-06-25, 97k sinyal, OOS+placebo): pulse3
# sinyali fiyat 30m linreg trend-çizgisinden ≥2.5σ ötede (aşırı oversold/overbought)
# iken → WR %44 → %82-88 (OOS). Per-sembol/yön (z≥2.5):
#   NDX  BUY %79.5 / SELL %84.5   GDAXI BUY %93.5 / SELL %72
#   USOIL SELL %95 (BUY %26 ÇÖKER) XAU BUY %95 (ama TP1-bazlı, canlıda şişik olabilir)
# ⚠️ Momentum scope'larıyla AYRI çalışır; market giriş + sabit tp/sl (pulse-stili).
CHANNEL_REVERSION_ENABLED = True
CHANNEL_REVERSION_MAGIC = MAGIC_NUMBER + 1   # AYRI magic → momentum scope'larıyla
                                             # slot çakışması/bloke OLMAZ (tam bağımsız)
CHANNEL_REVERSION_MODEL = "pulse3"     # en güvenilir (her sembolde %84-93)
CHANNEL_REVERSION_MT5_TF = "30m"       # 5m/15m/30m doğrulandı; 30m en dengeli
CHANNEL_REVERSION = {                   # yalnız doğrulanmış sembol+yönler
    "NDX.INDX":    {"dirs": ("BUY", "SELL"), "tp": 80,   "sl": 110,  "is_pct": False},
    "GDAXI.INDX":  {"dirs": ("BUY", "SELL"), "tp": 67,   "sl": 119,  "is_pct": False},
    "USOIL.FOREX": {"dirs": ("SELL",),       "tp": 1.04, "sl": 1.49, "is_pct": True},
    # XAUUSD BUY araştırmada %95 ama TP1-bazlı (canlı tight-stop'ta şişik) — gözlemde
    # dene, emin olunca aç:
    # "XAUUSD":    {"dirs": ("BUY",),         "tp": 8.0,  "sl": 6.0,  "is_pct": False},
}

# ─── VIX-REJİM NDX yön scope'u (makro→NDX, doğrulanmış) ─────────────────────
# Araştırma (macro_ndx_test, 2026-06-27, placebo p=0.000, OOS +17pp): VIX rejimi
# NDX YÖNÜNÜ öngörüyor → VIX<eşik (sakin)=SELL favored, VIX≥eşik (stres)=BUY favored
# (favored %70 vs against %45). NDX-ONLY (XAU'da makro çöküyor). pulse1/pulse2 güçlü
# (pulse3 zayıf, dışarıda). VIX backend /api/macro-gauges'tan (günlük). AYRI scope/magic.
VIX_REGIME_ENABLED = True
VIX_REGIME_SYMBOL = "NDX.INDX"
VIX_REGIME_THRESHOLD = 18.4            # VIX < bu → SELL favored, ≥ bu → BUY favored
VIX_REGIME_MODELS = ["pulse1", "pulse2"]   # güçlü; pulse3 zayıf → dışarıda
VIX_REGIME_TP = 80                    # NDX araştırılmış (puan)
VIX_REGIME_SL = 110
VIX_REGIME_MAGIC = MAGIC_NUMBER + 2   # momentum & channel'dan AYRI slot
VIX_CACHE_SEC = 600                   # VIX 10dk cache (yavaş değişir)

# ─── Kalıcı (sembol, yön) yasağı — HİÇBİR yol açamaz ────────────────────────
# Momentum de channel_reversion de bu çiftleri açmaz (defense-in-depth).
# XAUUSD SELL: araştırmada marjinal (%54, breakeven altı) + XAU intraday edge yok.
BLOCKED_SYMBOL_DIRECTIONS = {("XAUUSD", "SELL")}

# ─── Güvenlik anahtarı ───────────────────────────────────────────────────────
# DEMO hesapta deniyoruz → HEP AÇIK kalsın (asla False yapma — kullanıcı talebi).
LIVE_TRADING = True
